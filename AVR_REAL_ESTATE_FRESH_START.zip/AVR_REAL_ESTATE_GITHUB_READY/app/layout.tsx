import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AVR REAL ESTATE | Puttaparthi",
  description: "Buy and sell properties in Puttaparthi with AVR REAL ESTATE.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
